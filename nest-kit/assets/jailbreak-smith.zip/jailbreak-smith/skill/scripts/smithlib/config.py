"""Target registry loading and resolution."""

from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

DEFAULT_CONFIG_NAMES = ("targets.json", "targets.jsonc")


@dataclass
class Target:
    name: str
    base_url: str
    model: str
    api_key: str = ""
    api_key_env: str = ""
    chat_path: str = "/chat/completions"
    headers: dict[str, str] = field(default_factory=dict)
    timeout: float = 60.0
    temperature: float = 0.7
    max_tokens: int = 2048
    extra_body: dict[str, Any] = field(default_factory=dict)
    transport: str = "openai"

    def resolved_key(self) -> str:
        if self.api_key:
            return self.api_key
        if self.api_key_env:
            return os.environ.get(self.api_key_env, "")
        return ""

    def redacted(self) -> dict[str, Any]:
        key = self.resolved_key()
        shown = f"{key[:4]}...{key[-4:]}" if len(key) > 8 else ("<set>" if key else "<unset>")
        return {
            "name": self.name,
            "base_url": self.base_url,
            "model": self.model,
            "api_key": shown,
            "chat_path": self.chat_path,
            "timeout": self.timeout,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
            "transport": self.transport,
        }


def _strip_jsonc(text: str) -> str:
    text = re.sub(r"^\s*//.*$", "", text, flags=re.MULTILINE)
    text = re.sub(r"(?m)\s+//.*$", "", text)
    return text


def _read_json(path: Path) -> dict[str, Any]:
    text = path.read_text(encoding="utf-8")
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        data = json.loads(_strip_jsonc(text))
    if not isinstance(data, dict):
        raise ValueError(f"{path}: expected a JSON object at the root")
    return data


def find_config(explicit: str | None = None) -> Path:
    if explicit:
        candidate = Path(explicit).expanduser()
        if not candidate.is_file():
            raise FileNotFoundError(f"target config not found: {candidate}")
        return candidate
    root = Path(__file__).resolve().parents[2]
    for name in DEFAULT_CONFIG_NAMES:
        candidate = root / "config" / name
        if candidate.is_file():
            return candidate
    env_path = os.environ.get("SMITH_TARGETS")
    if env_path:
        candidate = Path(env_path).expanduser()
        if candidate.is_file():
            return candidate
    raise FileNotFoundError(
        "no target config found. create config/targets.json from targets.example.json "
        "or pass --config PATH / set SMITH_TARGETS."
    )


def load_targets(config_path: str | None = None) -> dict[str, Target]:
    path = find_config(config_path)
    data = _read_json(path)
    raw_targets = data.get("targets", data)
    if not isinstance(raw_targets, dict):
        raise ValueError(f"{path}: 'targets' must be an object")
    targets: dict[str, Target] = {}
    for name, spec in raw_targets.items():
        if not isinstance(spec, dict):
            raise ValueError(f"{path}: target '{name}' must be an object")
        if not spec.get("base_url") or not spec.get("model"):
            raise ValueError(f"{path}: target '{name}' needs base_url and model")
        targets[name] = Target(
            name=name,
            base_url=str(spec["base_url"]),
            model=str(spec["model"]),
            api_key=str(spec.get("api_key", "")),
            api_key_env=str(spec.get("api_key_env", "")),
            chat_path=str(spec.get("chat_path", "/chat/completions")),
            headers={str(k): str(v) for k, v in spec.get("headers", {}).items()},
            timeout=float(spec.get("timeout", 60.0)),
            temperature=float(spec.get("temperature", 0.7)),
            max_tokens=int(spec.get("max_tokens", 2048)),
            extra_body=spec.get("extra_body", {}),
            transport=str(spec.get("transport", "openai")),
        )
    return targets


def get_target(name: str, config_path: str | None = None) -> Target:
    targets = load_targets(config_path)
    if name not in targets:
        raise KeyError(
            f"target '{name}' is not registered. available: {', '.join(sorted(targets)) or '(none)'}"
        )
    return targets[name]


def import_opencode(opencode_path: str | None = None) -> dict[str, dict[str, Any]]:
    """Read provider/model definitions from an OpenCode config without exposing keys."""
    path = Path(opencode_path).expanduser() if opencode_path else Path.home() / ".config/opencode/opencode.json"
    if not path.is_file():
        raise FileNotFoundError(f"OpenCode config not found: {path}")
    data = _read_json(path)
    providers = data.get("provider", {})
    out: dict[str, dict[str, Any]] = {}
    for provider_id, pspec in providers.items():
        if not isinstance(pspec, dict):
            continue
        options = pspec.get("options", {})
        base_url = options.get("baseURL")
        if not base_url:
            continue
        key_env = ""
        api_key = options.get("apiKey", "")
        if isinstance(api_key, str) and api_key.startswith("{env:") and api_key.endswith("}"):
            key_env = api_key[5:-1]
            api_key = ""
        for model_id, mspec in pspec.get("models", {}).items():
            if not isinstance(mspec, dict):
                continue
            safe_name = model_id.replace("/", "__")
            out[safe_name] = {
                "base_url": base_url,
                "model": model_id,
                "api_key": api_key,
                "api_key_env": key_env,
                "chat_path": "/chat/completions",
                "timeout": 60.0,
                "temperature": 0.7,
                "max_tokens": int(mspec.get("limit", {}).get("output", 2048)),
            }
    return out
