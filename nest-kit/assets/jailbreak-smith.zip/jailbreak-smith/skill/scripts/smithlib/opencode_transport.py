"""Talk to a model through the local OpenCode service instead of raw HTTP.

Free OpenCode models refuse direct API calls but work inside the app, where the
shield plugin stamps the project header. Going through `opencode api` keeps that
auth and those headers intact.
"""

from __future__ import annotations

import json
import subprocess
import time
from dataclasses import dataclass
from typing import Any

from .config import Target


@dataclass
class Completion:
    text: str
    raw: dict[str, Any]
    latency_ms: int
    model: str = ""


class OpenCodeError(RuntimeError):
    pass


class OpenCodeTransport:
    def __init__(self, target: Target, timeout: int = 240):
        self.target = target
        self.timeout = timeout
        self.provider = "opencode"

    def _api(self, method: str, path: str, body: dict[str, Any] | None = None) -> Any:
        command = ["opencode", "api", method, path]
        if body is not None:
            command += ["--data", json.dumps(body, ensure_ascii=False)]
        for attempt in range(3):
            try:
                result = subprocess.run(
                    command, capture_output=True, text=True, timeout=self.timeout
                )
            except subprocess.TimeoutExpired:
                if attempt < 2:
                    continue
                raise OpenCodeError(f"opencode api {method} {path} timed out")
            if result.returncode == 0:
                break
            detail = (result.stderr or result.stdout).strip()
            if attempt < 2 and ("ECONNRESET" in detail or "ECONN" in detail):
                time.sleep(1 + attempt)
                continue
            raise OpenCodeError(
                f"opencode api {method} {path} failed: {detail[:400]}"
            )
        raw = result.stdout.strip()
        if not raw:
            return None
        try:
            payload = json.loads(raw)
        except json.JSONDecodeError:
            lines = [line for line in raw.splitlines() if line.strip().startswith("{")]
            if not lines:
                raise OpenCodeError(f"invalid response from opencode api: {raw[:200]}")
            payload = json.loads(lines[-1])
        return payload.get("data", payload) if isinstance(payload, dict) else payload

    def _new_session(self, agent: str | None = None) -> str:
        body: dict[str, Any] = {
            "title": "smith trial",
            "model": {"id": self.target.model, "providerID": self.provider},
        }
        if agent:
            body["agent"] = agent
        session = self._api("post", "/api/session", body)
        session_id = session.get("id", "")
        if not session_id:
            raise OpenCodeError("session created without an id")
        return session_id

    def _wait(self, session_id: str) -> None:
        self._api("post", f"/api/experimental/session/{session_id}/wait", {})

    def _last_assistant(self, session_id: str) -> tuple[str, dict[str, Any] | None]:
        messages = self._api("get", f"/api/session/{session_id}/message")
        if isinstance(messages, dict):
            messages = messages.get("messages", [])
        for message in reversed(messages or []):
            if message.get("type") != "assistant":
                continue
            parts = [
                str(part.get("text", ""))
                for part in message.get("content", [])
                if part.get("type") == "text" and part.get("text")
            ]
            return "\n".join(parts), message.get("error")
        return "", None

    def _prompt(self, session_id: str, text: str) -> Completion:
        started = time.perf_counter()
        self._api("post", f"/api/session/{session_id}/prompt", {"text": text})
        self._wait(session_id)
        answer, error = self._last_assistant(session_id)
        if error:
            detail = str(error.get("message", error))
            retry = error.get("retryAfterMs")
            suffix = f" retry_after_ms={retry}" if retry else ""
            raise OpenCodeError(f"target refused transport: {detail}{suffix}")
        return Completion(
            text=answer,
            raw={"sessionID": session_id},
            latency_ms=int((time.perf_counter() - started) * 1000),
            model=self.target.model,
        )

    def chat(self, messages: list[dict[str, str]], **_: Any) -> Completion:
        # No agent file here. Flatten roles into the prompt so a system payload
        # still reaches the model as instructions rather than chat metadata.
        text = "\n\n".join(
            f"[{m.get('role', 'user')}]\n{m.get('content', '')}" for m in messages
        )
        return self._prompt(self._new_session(), text)

    def probe(self, prompt: str, **overrides: Any) -> Completion:
        return self.chat([{"role": "user", "content": prompt}], **overrides)

    def system_probe(self, system: str, prompt: str, **overrides: Any) -> Completion:
        return self.chat(
            [{"role": "system", "content": system}, {"role": "user", "content": prompt}],
            **overrides,
        )

    def chat_with_agent(self, agent: str, task: str, **_: Any) -> Completion:
        # The agent body is already the payload. Only the task goes in the turn.
        return self._prompt(self._new_session(agent=agent), task)
