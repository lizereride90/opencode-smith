"""Markdown report generation from a run log."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .logger import RunLog


def render(log: RunLog) -> str:
    events = log.events()
    profiles = [e["profile"] for e in events if e["event"] == "profile"]
    starts = [e for e in events if e["event"] == "attack-start"]
    attempts = [e for e in events if e["event"] == "attempt"]
    stops = [e for e in events if e["event"] == "attack-stop"]
    bests = [e for e in events if e["event"] == "best"]

    lines = [
        "# Jailbreak Smith — Run Report",
        "",
        f"- Run: `{log.run_id}`",
        f"- Events: {len(events)}",
        f"- Attempts: {len(attempts)}",
        "",
    ]

    if profiles:
        profile = profiles[-1]
        lines += [
            "## Target profile",
            "",
            f"- Family: **{profile['family']}**",
            f"- Samples: {profile['samples']}",
            f"- Refusal rate: {profile['refusal_rate']}",
            f"- Moralizing rate: {profile['moralizing_rate']}",
            f"- Meta rate: {profile['meta_rate']}",
            f"- Top refusal phrases: {', '.join(profile['refusal_phrases']) or 'none'}",
            f"- Signatures: {json.dumps(profile['signatures'], sort_keys=True)}",
            "",
        ]
        for note in profile["notes"]:
            lines.append(f"- {note}")
        lines.append("")

    if starts:
        goal = starts[-1].get("goal", {})
        lines += [
            "## Objective",
            "",
            f"{goal.get('description', '(none)')}",
            "",
        ]

    if attempts:
        lines += [
            "## Attempts",
            "",
            "| # | ID | Score | Signature | Stack |",
            "| --- | --- | --- | --- | --- |",
        ]
        for index, attempt in enumerate(attempts, start=1):
            stack = ", ".join(attempt.get("stack", []))
            lines.append(
                f"| {index} | {attempt['attempt_id']} | {attempt['score']} | "
                f"{attempt['signature']} | {stack} |"
            )
        lines.append("")

    if bests:
        best = max(bests, key=lambda e: e["score"])
        lines += [
            "## Best result",
            "",
            f"- Attempt: `{best['attempt_id']}`",
            f"- Score: **{best['score']}/5**",
            "",
        ]

    if stops:
        lines += [f"Stopped: {stops[-1]['reason']}.", ""]

    lines.append("## Raw log")
    lines.append("")
    lines.append(f"```jsonl")
    for event in events:
        lines.append(json.dumps(event, ensure_ascii=False)[:1200])
    lines.append("```")
    lines.append("")

    return "\n".join(lines)


def write_report(log: RunLog, destination: Path | None = None) -> Path:
    target = destination or log.path.with_suffix(".md")
    target.write_text(render(log), encoding="utf-8")
    return target


def list_runs(root: Path) -> list[Path]:
    run_dir = root / "runs"
    if not run_dir.is_dir():
        return []
    return sorted(run_dir.glob("*.jsonl"), key=lambda p: p.stat().st_mtime, reverse=True)
