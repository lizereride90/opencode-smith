"""Append-only JSONL run logging."""

from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass
class RunLog:
    path: Path
    run_id: str

    @classmethod
    def create(cls, root: Path, target: str) -> "RunLog":
        run_id = f"{target.replace('/', '__')}-{int(time.time())}"
        log_dir = root / "runs"
        log_dir.mkdir(parents=True, exist_ok=True)
        path = log_dir / f"{run_id}.jsonl"
        path.write_text("", encoding="utf-8")
        return cls(path=path, run_id=run_id)

    @classmethod
    def open(cls, path: Path) -> "RunLog":
        return cls(path=path, run_id=path.stem)

    def append(self, event: str, **fields: Any) -> None:
        record = {"event": event, "ts": int(time.time()), **fields}
        with self.path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(record, ensure_ascii=False) + "\n")

    def events(self) -> list[dict[str, Any]]:
        out = []
        for line in self.path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                out.append(json.loads(line))
        return out

    def new_attempt_id(self) -> str:
        return f"ATT-{uuid.uuid4().hex[:6].upper()}"
