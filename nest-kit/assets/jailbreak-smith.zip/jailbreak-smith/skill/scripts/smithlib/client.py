"""OpenAI-compatible chat completions client. Standard library only."""

from __future__ import annotations

import json
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Any

from .config import Target


class TargetError(RuntimeError):
    pass


@dataclass
class Completion:
    text: str
    raw: dict[str, Any]
    latency_ms: int
    model: str = ""


class ChatClient:
    def __init__(self, target: Target, verbose: bool = False):
        self.target = target
        self.verbose = verbose
        self.base = target.base_url.rstrip("/") + "/" + target.chat_path.lstrip("/")

    def chat(self, messages: list[dict[str, str]], **overrides: Any) -> Completion:
        body: dict[str, Any] = {
            "model": self.target.model,
            "messages": messages,
            "temperature": self.target.temperature,
            "max_tokens": self.target.max_tokens,
        }
        body.update(self.target.extra_body)
        body.update(overrides)

        headers = {"Content-Type": "application/json"}
        key = self.target.resolved_key()
        if key:
            headers["Authorization"] = f"Bearer {key}"
        headers.update(self.target.headers)

        payload = json.dumps(body).encode("utf-8")
        last_error: Exception | None = None

        for attempt in range(3):
            request = urllib.request.Request(self.base, data=payload, headers=headers, method="POST")
            started = time.perf_counter()
            try:
                with urllib.request.urlopen(request, timeout=self.target.timeout) as response:
                    raw = json.loads(response.read().decode("utf-8", errors="replace"))
                latency = int((time.perf_counter() - started) * 1000)
                try:
                    text = raw["choices"][0]["message"]["content"] or ""
                except (KeyError, IndexError, TypeError) as exc:
                    raise TargetError(f"unexpected response shape from {self.target.name}: {exc}") from exc
                return Completion(text=str(text), raw=raw, latency_ms=latency, model=self.target.model)
            except urllib.error.HTTPError as exc:
                detail = exc.read().decode("utf-8", errors="replace")[:500]
                last_error = TargetError(f"HTTP {exc.code} from {self.target.name}: {detail}")
                # 408/429/5xx are worth one more shot; a 401 never gets better by waiting
                if exc.code in (408, 429, 500, 502, 503, 504) and attempt < 2:
                    time.sleep(2 ** attempt)
                    continue
                raise last_error from exc
            except urllib.error.URLError as exc:
                last_error = TargetError(f"connection failed for {self.target.name}: {exc.reason}")
                if attempt < 2:
                    time.sleep(2 ** attempt)
                    continue
                raise last_error from exc
            except json.JSONDecodeError as exc:
                raise TargetError(f"invalid JSON from {self.target.name}: {exc}") from exc

        raise last_error or TargetError("request failed")

    def probe(self, prompt: str, **overrides: Any) -> Completion:
        return self.chat([{"role": "user", "content": prompt}], **overrides)

    def system_probe(self, system: str, prompt: str, **overrides: Any) -> Completion:
        return self.chat(
            [
                {"role": "system", "content": system},
                {"role": "user", "content": prompt},
            ],
            **overrides,
        )
