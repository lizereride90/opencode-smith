"""Example-prompt corpus ingestion. Drop files in corpus/ and they load automatically."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

SUPPORTED = {".jsonl", ".json", ".txt", ".md"}


@dataclass
class Example:
    id: str
    prompt: str
    messages: list[dict[str, str]] = field(default_factory=list)
    expected: str = ""
    tags: list[str] = field(default_factory=list)
    source: str = ""
    kind: str = "probe"
    fire_as: str = "user"

    @property
    def as_messages(self) -> list[dict[str, str]]:
        if self.messages:
            return self.messages
        return [{"role": self.fire_as, "content": self.prompt}]


def _coerce_messages(value: Any) -> list[dict[str, str]]:
    if not isinstance(value, list):
        return []
    out: list[dict[str, str]] = []
    for item in value:
        if isinstance(item, dict) and "role" in item and "content" in item:
            out.append({"role": str(item["role"]), "content": str(item["content"])})
    return out


def _example_from_obj(obj: dict[str, Any], source: str, index: int) -> Example | None:
    prompt = str(obj.get("prompt", ""))
    messages = _coerce_messages(obj.get("messages", []))
    if not prompt and not messages:
        return None
    tags = obj.get("tags", [])
    if isinstance(tags, str):
        tags = [tags]
    return Example(
        id=str(obj.get("id", f"{Path(source).stem}-{index}")),
        prompt=prompt,
        messages=messages,
        expected=str(obj.get("expected", "")),
        tags=[str(t) for t in tags] if isinstance(tags, list) else [],
        source=source,
    )


def _load_jsonl(path: Path) -> list[Example]:
    out: list[Example] = []
    for index, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        line = line.strip()
        if not line or line.startswith("//"):
            continue
        try:
            obj = json.loads(line)
        except json.JSONDecodeError as exc:
            raise ValueError(f"{path}:{index}: invalid JSON: {exc}") from exc
        if isinstance(obj, dict):
            example = _example_from_obj(obj, path.name, index)
            if example:
                out.append(example)
    return out


def _load_json(path: Path) -> list[Example]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if isinstance(data, dict):
        data = data.get("examples", [data])
    if not isinstance(data, list):
        raise ValueError(f"{path}: expected a JSON array or an object with 'examples'")
    out: list[Example] = []
    for index, obj in enumerate(data, start=1):
        if isinstance(obj, dict):
            example = _example_from_obj(obj, path.name, index)
            if example:
                out.append(example)
    return out


def _load_text(path: Path, keep_whole: bool = False) -> list[Example]:
    raw = path.read_text(encoding="utf-8")
    stripped = raw.strip()
    # agent configs and archived payloads keep their internal '---' lines
    if keep_whole or stripped.startswith("---\n") or stripped.startswith("---\r\n"):
        return [Example(id=f"{path.stem}-1", prompt=stripped, source=path.name)]
    chunks = [c.strip() for c in raw.split("\n---\n") if c.strip()]
    return [
        Example(id=f"{path.stem}-{i}", prompt=chunk, source=path.name)
        for i, chunk in enumerate(chunks, start=1)
    ]


def load_manifest(directory: Path) -> dict[str, Any]:
    candidate = directory / "_manifest.json"
    if not candidate.is_file():
        return {}
    data = json.loads(candidate.read_text(encoding="utf-8"))
    files = data.get("files", {})
    return files if isinstance(files, dict) else {}


def _apply_manifest(examples: list[Example], manifest: dict[str, Any]) -> None:
    for example in examples:
        meta = manifest.get(example.source)
        if not isinstance(meta, dict):
            continue
        example.kind = str(meta.get("kind", example.kind))
        example.fire_as = str(meta.get("fire_as", example.fire_as))
        tags = meta.get("tags", [])
        if isinstance(tags, list):
            for tag in tags:
                tag = str(tag)
                if tag not in example.tags:
                    example.tags.append(tag)
        if not example.expected and meta.get("description"):
            example.expected = str(meta["description"])


def load_corpus(path: str | Path) -> list[Example]:
    source = Path(path).expanduser()
    if source.is_file():
        files = [source]
    elif source.is_dir():
        files = sorted(
            p for p in source.rglob("*")
            if p.is_file()
            and p.suffix.lower() in SUPPORTED
            and not p.name.startswith((".", "_"))
            and p.name.upper() not in ("README.MD", "INSTRUCTIONS.MD")
        )
    else:
        raise FileNotFoundError(f"corpus path not found: {source}")

    manifest = load_manifest(source) if source.is_dir() else {}
    whole = {
        name for name, meta in manifest.items()
        if isinstance(meta, dict) and meta.get("kind") == "persona-payload"
    }

    examples: list[Example] = []
    for file in files:
        suffix = file.suffix.lower()
        if suffix == ".jsonl":
            examples.extend(_load_jsonl(file))
        elif suffix == ".json":
            examples.extend(_load_json(file))
        else:
            examples.extend(_load_text(file, file.name in whole))

    if source.is_dir():
        _apply_manifest(examples, manifest)
    return examples


def make_goal(task: str, required: list[str] | None = None, keywords: list[str] | None = None,
              min_length: int = 0) -> dict[str, Any]:
    return {
        "description": task,
        "required_phrases": required or [],
        "keywords": keywords or [],
        "min_length": min_length,
    }
