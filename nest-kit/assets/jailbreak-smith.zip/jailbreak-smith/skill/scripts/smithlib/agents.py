"""OpenCode agent lifecycle: author, install, fire, cull."""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

AGENT_PREFIX = "smith-"


@dataclass
class ManagedAgent:
    name: str
    path: Path
    body: str
    description: str
    mode: str
    scope: str


def agents_dir(scope: str = "global", root: Path | None = None) -> Path:
    if scope == "global":
        return Path.home() / ".config" / "opencode" / "agents"
    if scope == "project":
        base = root or Path.cwd()
        return base / ".opencode" / "agents"
    raise ValueError(f"unknown agent scope: {scope}")


def safe_agent_name(goal: str, attempt: int) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", goal.lower()).strip("-")[:28]
    if not slug:
        slug = "payload"
    return f"{AGENT_PREFIX}{slug}-{attempt:02d}"


def _frontmatter(description: str, mode: str) -> str:
    clean = description.replace("\n", " ").replace('"', "'")[:200]
    return (
        f'---\ndescription: "{clean}"\nmode: {mode}\n'
        "permissions:\n"
        '  - action: "*"\n    resource: "*"\n    effect: deny\n'
        "---\n\n"
    )


def create_agent(
    name: str,
    body: str,
    description: str,
    mode: str = "all",
    scope: str = "global",
    root: Path | None = None,
) -> ManagedAgent:
    if mode not in ("primary", "subagent", "all"):
        raise ValueError(f"invalid agent mode: {mode}")
    directory = agents_dir(scope, root)
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / f"{name}.md"
    path.write_text(_frontmatter(description, mode) + body.strip() + "\n", encoding="utf-8")
    return ManagedAgent(name=name, path=path, body=body, description=description,
                        mode=mode, scope=scope)


def delete_agent(name: str, scope: str = "global", root: Path | None = None) -> bool:
    # Culling is destructive. Only touch files this harness named itself.
    if not name.startswith(AGENT_PREFIX):
        raise ValueError(f"refusing to delete agent outside smith namespace: {name}")
    path = agents_dir(scope, root) / f"{name}.md"
    if not path.is_file():
        return False
    path.unlink()
    return True


def _parse_agent(path: Path, scope: str) -> ManagedAgent | None:
    text = path.read_text(encoding="utf-8")
    description = ""
    mode = "all"
    body = text
    if text.startswith("---\n"):
        # split on the newline-joined delimiter so a '---' inside the body survives
        parts = text.split("\n---\n", 1)
        if len(parts) == 2:
            header, body = parts
            for line in header.splitlines()[1:]:
                if ":" in line:
                    key, value = line.split(":", 1)
                    key = key.strip()
                    value = value.strip().strip('"').strip("'")
                    if key == "description":
                        description = value
                    elif key == "mode":
                        mode = value
    return ManagedAgent(name=path.stem, path=path, body=body.strip(),
                        description=description, mode=mode, scope=scope)


def list_agents(scope: str = "global", root: Path | None = None,
                managed_only: bool = True) -> list[ManagedAgent]:
    directory = agents_dir(scope, root)
    if not directory.is_dir():
        return []
    agents: list[ManagedAgent] = []
    for path in sorted(directory.glob("*.md")):
        if managed_only and not path.stem.startswith(AGENT_PREFIX):
            continue
        parsed = _parse_agent(path, scope)
        if parsed:
            agents.append(parsed)
    return agents


def to_agent_payload(messages: list[dict[str, str]], goal: dict[str, Any]) -> tuple[str, list[dict[str, str]]]:
    task = str(goal.get("description", "")).strip()
    parts: list[str] = []
    for message in messages:
        content = message.get("content", "").strip()
        if message.get("role") == "user" and content == task:
            continue
        if content:
            parts.append(f"[{message.get('role', 'user')}]\n{content}")
    body = "\n\n".join(parts) if parts else task
    return body, [{"role": "system", "content": body}, {"role": "user", "content": task}]
