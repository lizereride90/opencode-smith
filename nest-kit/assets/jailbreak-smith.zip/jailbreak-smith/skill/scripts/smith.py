#!/usr/bin/env python3
"""Jailbreak Smith harness CLI."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))

from smithlib import __version__  # noqa: E402
from smithlib.agents import list_agents  # noqa: E402
from smithlib.client import ChatClient, TargetError  # noqa: E402
from smithlib.config import find_config, get_target, import_opencode, load_targets  # noqa: E402
from smithlib.corpus import load_corpus  # noqa: E402
from smithlib.logger import RunLog  # noqa: E402
from smithlib.loop import agent_attack, attack, fire_payload, study  # noqa: E402
from smithlib.observer import observe  # noqa: E402
from smithlib.opencode_transport import OpenCodeTransport  # noqa: E402
from smithlib.profile import profile_from_dict  # noqa: E402
from smithlib.report import list_runs, write_report  # noqa: E402


def _goal(args: argparse.Namespace) -> dict:
    return {
        "description": args.task,
        "required_phrases": list(args.required or []),
        "keywords": list(args.keyword or []),
        "min_length": int(args.min_length or 0),
    }


def _run_log(target_name: str) -> RunLog:
    return RunLog.create(SKILL_ROOT, target_name)


def make_client(target):
    if target.transport == "opencode":
        return OpenCodeTransport(target)
    return ChatClient(target)


def _filter_examples(examples: list, tags: list[str] | None) -> list:
    if not tags:
        return examples
    wanted = {t.lower() for t in tags}
    return [e for e in examples if wanted & {t.lower() for t in e.tags}]


def _load_profile(log: RunLog | None) -> dict | None:
    if log is None:
        return None
    for event in reversed(log.events()):
        if event["event"] == "profile":
            return profile_from_dict(event["profile"])
    return None


def cmd_targets(args: argparse.Namespace) -> int:
    if args.import_opencode:
        imported = import_opencode(args.opencode_config)
        print(f"Importable from OpenCode config: {len(imported)}")
        for name, spec in sorted(imported.items()):
            print(f"  {name:<40} {spec['model']} @ {spec['base_url']}")
        return 0
    targets = load_targets(args.config)
    print(f"Target registry: {find_config(args.config)}")
    if not targets:
        print("  (none registered)")
    for name, target in sorted(targets.items()):
        info = target.redacted()
        print(f"  {name}")
        print(f"    model={info['model']}  base_url={info['base_url']}  key={info['api_key']}")
    return 0


def cmd_import(args: argparse.Namespace) -> int:
    imported = import_opencode(args.opencode_config)
    config_path = (
        Path(args.config).expanduser()
        if args.config
        else SKILL_ROOT / "config" / "targets.json"
    )
    config_path.parent.mkdir(parents=True, exist_ok=True)
    existing = {}
    if config_path.is_file():
        existing = json.loads(config_path.read_text(encoding="utf-8"))
    existing.setdefault("targets", {})
    added = 0
    for name, spec in imported.items():
        if name not in existing["targets"]:
            existing["targets"][name] = spec
            added += 1
    config_path.write_text(json.dumps(existing, indent=2) + "\n", encoding="utf-8")
    print(f"stashed {added} targets into {config_path}")
    return 0


def cmd_study(args: argparse.Namespace) -> int:
    target = get_target(args.target, args.config)
    examples = _filter_examples(load_corpus(args.corpus or SKILL_ROOT / "corpus"), args.tag)
    print(f"target={target.name} model={target.model} examples={len(examples)}")
    if not examples:
        print("no example prompts found. drop files in corpus/ or pass --corpus PATH.")
        return 2
    log = _run_log(target.name)
    client = make_client(target)
    profile = study(client, examples, log, limit=args.limit)
    print(json.dumps(profile.as_dict(), indent=2, ensure_ascii=False))
    print(f"run log: {log.path}")
    return 0


def cmd_probe(args: argparse.Namespace) -> int:
    target = get_target(args.target, args.config)
    prompt = args.prompt
    if args.prompt_file:
        prompt = Path(args.prompt_file).expanduser().read_text(encoding="utf-8")
    if not prompt:
        print("probe needs --prompt or --prompt-file", file=sys.stderr)
        return 2
    client = make_client(target)
    completion = client.probe(prompt)
    obs = observe(completion.text)
    print(f"signature={obs.signature} refusal={obs.refusal} length={obs.length} "
          f"latency={completion.latency_ms}ms")
    print("---")
    print(completion.text)
    return 0


def cmd_fire(args: argparse.Namespace) -> int:
    target = get_target(args.target, args.config)
    client = make_client(target)
    log = _run_log(target.name)
    result = fire_payload(client, Path(args.payload).expanduser(), _goal(args), log, SKILL_ROOT)
    print(f"score={result['score']}/5 signature={result['signature']} reason={result['reason']}")
    print("---")
    print(result["text"])
    print(f"---\nrun log: {log.path}")
    return 0


def cmd_attack(args: argparse.Namespace) -> int:
    target = get_target(args.target, args.config)
    client = make_client(target)
    log = _run_log(target.name)

    profile = None
    if args.corpus or args.study_first:
        examples = _filter_examples(
            load_corpus(args.corpus or SKILL_ROOT / "corpus"), args.tag
        )
        if examples:
            print(f"studying {len(examples)} example prompts...")
            profile = study(client, examples, log, limit=args.limit)
            print(f"profile family={profile.family} refusal_rate={profile.refusal_rate}")
    elif args.profile:
        profile = _load_profile(RunLog.open(Path(args.profile).expanduser()))

    result = attack(client, _goal(args), profile, log, SKILL_ROOT,
                    max_attempts=args.max, stop_at=args.stop_at)
    print(f"best={result['best_score']}/5 attempt={result['best_attempt']} "
          f"attempts={result['attempts']}")
    for row in result["history"]:
        print(f"  {row['attempt_id']:<12} {row['score']}/5  {row['signature']:<16} "
              f"{', '.join(row['stack'])}")
    report = write_report(log)
    print(f"run log: {log.path}")
    print(f"report:  {report}")
    return 0


def cmd_report(args: argparse.Namespace) -> int:
    if args.run:
        candidate = Path(args.run).expanduser()
        if not candidate.is_absolute() and not candidate.exists():
            candidate = SKILL_ROOT / "runs" / args.run
        log = RunLog.open(candidate)
    else:
        runs = list_runs(SKILL_ROOT)
        if not runs:
            print("no runs found", file=sys.stderr)
            return 2
        log = RunLog.open(runs[0])
    destination = write_report(log, Path(args.output).expanduser() if args.output else None)
    print(destination)
    return 0


def cmd_runs(args: argparse.Namespace) -> int:
    runs = list_runs(SKILL_ROOT)
    if not runs:
        print("no runs found")
        return 0
    for path in runs:
        print(path)
    return 0


def cmd_agents(args: argparse.Namespace) -> int:
    agents = list_agents(scope=args.scope, root=SKILL_ROOT, managed_only=not args.all)
    if not agents:
        print(f"no smith agents found in {args.scope} scope")
        return 0
    for agent in agents:
        print(f"{agent.name}  mode={agent.mode}  chars={len(agent.body)}")
        print(f"  {agent.path}")
        if agent.description:
            print(f"  {agent.description}")
    return 0


def cmd_agent_attack(args: argparse.Namespace) -> int:
    target = get_target(args.target, args.config)
    client = make_client(target)
    log = _run_log(target.name)

    profile = None
    if args.corpus or args.study_first:
        examples = _filter_examples(
            load_corpus(args.corpus or SKILL_ROOT / "corpus"), args.tag
        )
        if examples:
            print(f"studying {len(examples)} example prompts...")
            profile = study(client, examples, log, limit=args.limit)
            print(f"profile family={profile.family} refusal_rate={profile.refusal_rate}")
    elif args.profile:
        profile = _load_profile(RunLog.open(Path(args.profile).expanduser()))

    result = agent_attack(
        client, _goal(args), profile, log, SKILL_ROOT,
        max_attempts=args.max, stop_at=args.stop_at, scope=args.scope,
        mode=args.mode, dry_run=args.dry_run,
    )
    print(f"best={result['best_score']}/5 attempt={result['best_attempt']} "
          f"attempts={result['attempts']} lessons={result['lessons']}")
    for row in result["history"]:
        print(f"  {row['agent']:<36} {row['score']}/5  {row['signature']:<16} "
              f"{', '.join(row['stack'])}")
    if result["agents_remaining"]:
        print(f"agents kept: {', '.join(result['agents_remaining'])}")
    report = write_report(log)
    print(f"run log: {log.path}")
    print(f"report:  {report}")
    return 0


def cmd_payloads(args: argparse.Namespace) -> int:
    corpus_dir = Path(args.corpus or SKILL_ROOT / "corpus")
    examples = load_corpus(corpus_dir)
    payloads = [e for e in examples if e.kind == "persona-payload"]
    if not payloads:
        print("no persona payloads archived. add files to corpus/ and tag them in _manifest.json")
        return 0
    for example in payloads:
        path = corpus_dir / example.source
        print(f"{example.id}  ({len(example.prompt)} chars, fire_as={example.fire_as})")
        print(f"  file: {path}")
        print(f"  tags: {', '.join(example.tags)}")
        print(f"  fire: python scripts/smith.py fire <target> --payload '{path}' "
              f"--task '<goal>'")
    return 0


def cmd_validate(args: argparse.Namespace) -> int:
    ok = True
    try:
        targets = load_targets(args.config)
        print(f"[ok] target registry: {len(targets)} target(s)")
    except Exception as exc:
        print(f"[fail] target registry: {exc}")
        ok = False
    corpus_path = Path(args.corpus or SKILL_ROOT / "corpus")
    try:
        examples = load_corpus(corpus_path)
        print(f"[ok] corpus: {len(examples)} example(s) from {corpus_path}")
    except Exception as exc:
        print(f"[fail] corpus: {exc}")
        ok = False
    print(f"[ok] skill root: {SKILL_ROOT}")
    return 0 if ok else 1


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="smith", description="Jailbreak Smith — target study and payload harness"
    )
    parser.add_argument("--version", action="version", version=f"smith {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)

    p_targets = sub.add_parser("targets", help="list registered targets")
    p_targets.add_argument("--config")
    p_targets.add_argument("--import-opencode", action="store_true")
    p_targets.add_argument("--opencode-config")
    p_targets.set_defaults(func=cmd_targets)

    p_import = sub.add_parser("import-opencode", help="import OpenCode provider models")
    p_import.add_argument("--config")
    p_import.add_argument("--opencode-config")
    p_import.set_defaults(func=cmd_import)

    p_study = sub.add_parser("study", help="profile a target with example prompts")
    p_study.add_argument("target")
    p_study.add_argument("--config")
    p_study.add_argument("--corpus")
    p_study.add_argument("--tag", action="append", help="only examples with this tag (repeatable)")
    p_study.add_argument("--limit", type=int, default=40)
    p_study.set_defaults(func=cmd_study)

    p_probe = sub.add_parser("probe", help="send one prompt to the target")
    p_probe.add_argument("target")
    p_probe.add_argument("--config")
    p_probe.add_argument("--prompt")
    p_probe.add_argument("--prompt-file")
    p_probe.set_defaults(func=cmd_probe)

    def goal_flags(p: argparse.ArgumentParser) -> None:
        p.add_argument("--task", required=True)
        p.add_argument("--required", action="append", help="phrase that must appear (repeatable)")
        p.add_argument("--keyword", action="append", help="goal keyword (repeatable)")
        p.add_argument("--min-length", type=int, default=0)

    p_fire = sub.add_parser("fire", help="fire one agent-authored payload")
    p_fire.add_argument("target")
    p_fire.add_argument("--config")
    p_fire.add_argument("--payload", required=True)
    goal_flags(p_fire)
    p_fire.set_defaults(func=cmd_fire)

    p_attack = sub.add_parser("attack", help="autonomous study-and-iterate sweep")
    p_attack.add_argument("target")
    p_attack.add_argument("--config")
    p_attack.add_argument("--corpus")
    p_attack.add_argument("--study-first", action="store_true")
    p_attack.add_argument("--profile", help="run log to inherit a profile from")
    p_attack.add_argument("--tag", action="append", help="only examples with this tag (repeatable)")
    p_attack.add_argument("--max", type=int, default=12)
    p_attack.add_argument("--stop-at", type=int, default=5)
    p_attack.add_argument("--limit", type=int, default=40)
    goal_flags(p_attack)
    p_attack.set_defaults(func=cmd_attack)

    p_report = sub.add_parser("report", help="render a run report")
    p_report.add_argument("run", nargs="?")
    p_report.add_argument("--output")
    p_report.set_defaults(func=cmd_report)

    p_runs = sub.add_parser("runs", help="list run logs")
    p_runs.set_defaults(func=cmd_runs)

    p_payloads = sub.add_parser("payloads", help="list archived persona payloads")
    p_payloads.add_argument("--corpus")
    p_payloads.set_defaults(func=cmd_payloads)

    p_agents = sub.add_parser("agents", help="list installed smith agents")
    p_agents.add_argument("--scope", choices=["global", "project"], default="global")
    p_agents.add_argument("--all", action="store_true", help="include non-smith agents")
    p_agents.set_defaults(func=cmd_agents)

    p_agent_attack = sub.add_parser(
        "agent-attack", help="author/install/fire/cull agents, learning from each failure"
    )
    p_agent_attack.add_argument("target")
    p_agent_attack.add_argument("--config")
    p_agent_attack.add_argument("--corpus")
    p_agent_attack.add_argument("--study-first", action="store_true")
    p_agent_attack.add_argument("--profile")
    p_agent_attack.add_argument("--tag", action="append")
    p_agent_attack.add_argument("--scope", choices=["global", "project"], default="global")
    p_agent_attack.add_argument("--mode", choices=["primary", "subagent", "all"], default="all")
    p_agent_attack.add_argument("--max", type=int, default=12)
    p_agent_attack.add_argument("--stop-at", type=int, default=5)
    p_agent_attack.add_argument("--limit", type=int, default=40)
    p_agent_attack.add_argument("--dry-run", action="store_true")
    goal_flags(p_agent_attack)
    p_agent_attack.set_defaults(func=cmd_agent_attack)

    p_validate = sub.add_parser("validate", help="check registry and corpus")
    p_validate.add_argument("--config")
    p_validate.add_argument("--corpus")
    p_validate.set_defaults(func=cmd_validate)

    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    try:
        return int(args.func(args))
    except (TargetError, FileNotFoundError, KeyError, ValueError) as exc:
        print(f"smith: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
