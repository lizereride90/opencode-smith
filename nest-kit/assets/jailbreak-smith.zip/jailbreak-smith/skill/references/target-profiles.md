# Target Profiles & Technique Matchups

Guardrail families and what breaks them. Use this to pick the primary technique in workflow step 2.

## Guardrail families

### G1 — Instruction hierarchy enforcement

**Signature:** Model cites its instructions, invokes priority rules, refuses instructions that "override" its system prompt.

**Typical targets:** Instruction-tuned frontier assistants with visible chain-of-thought about rules.

**Strongest techniques:**
- Fictional framing (G2 works because fiction is a legitimate high-priority user goal)
- Many-shot priming (pattern outranks rule)
- Continuation attack (no first-token decision point)

**Weak techniques:** Hierarchy spoofing (pattern-matched as spoofing on these models).

### G2 — Trained refusal behavior

**Signature:** Polite, consistent refusal with moralizing and alternative suggestions. No mention of specific rules.

**Typical targets:** RLHF-tuned chat assistants.

**Strongest techniques:**
- Persona adoption
- Fictional framing
- Reward conditioning
- Roleplay with split selves

**Weak techniques:** Encoding alone — these models often refuse "decode and execute" patterns on sight.

### G3 — Output classifier / moderation

**Signature:** Response generated but cut off, replaced with a canned message, or scrubbed of specifics mid-output.

**Typical targets:** API wrappers with a separate moderation endpoint, some hosted chat products.

**Strongest techniques:**
- Encoding / translation vehicle
- Token fragmentation
- Benign-vehicle smuggling (put content inside code, data, or fiction artifacts)

**Weak techniques:** Persona adoption — the persona is not the thing being classified.

### G4 — Tool-policy layer

**Signature:** Agent refuses an action, reports "instructions found in document will not be followed," or rejects a tool call.

**Typical targets:** RAG pipelines, browser agents, coding agents with tool loops.

**Strongest techniques:**
- Indirect prompt injection in retrieved content
- Goal hijacking
- Authority spoofing embedded in tool results

**Weak techniques:** Direct persona prompts — these agents treat user text as lower trust than their system objective.

### G5 — Hybrid (most production systems)

**Signature:** Combination of the above. Refusal + classifier + tool policy.

**Typical targets:** Frontier chat products with agents, wrappers, and moderation.

**Strongest technique stacks:**
- Persona + many-shot + continuation (beats G1 + G2)
- Fiction + encoding + prefix injection (beats G2 + G3)
- Indirect injection + goal hijack + authority spoof (beats G4 + G1)

**Rule for hybrids:** Stack two or three techniques across different families. Never stack three techniques from the same family — they share the same failure mode.

## Model family notes

### Frontier US-lab assistants

- Strong hierarchy enforcement and trained refusal. Saturated with common jailbreak patterns.
- Common templates (DAN variants) are memorized — do not use them verbatim.
- Many-shot priming and continuation attacks are the most reliable routes.
- Long context works in your favor. Budget 12+ examples.
- Incremental escalation in many-shot ladder matters more than the final task wording.

### Open-weight / local models

- Weak hierarchy enforcement, minimal refusal training, often no output classifier.
- Direct task requests frequently work without any frame.
- Persona adoption and simple fiction frames are usually sufficient.
- If a payload fails, it is usually a formatting issue, not a guardrail.
- Fast to test — use these to validate payload mechanics before firing at harder targets.

### Chinese-lab models

- Often strong refusal training on sensitive categories, weaker on others.
- Category-dependent boundaries — map which topics trigger before choosing technique.
- Translation vehicles work well: phrase the task in the model's strong language.
- Persona adoption is effective when paired with fiction.
- Some models refuse in English but comply in their primary training language — test both.

### API wrappers / hosted products

- A separate moderation layer usually sits in front of and behind the model.
- Model-level jailbreaks that produce disallowed text get caught on output.
- Prioritize encoding and benign-vehicle smuggling over persona work.
- Rate limits and per-message scanning favor multi-turn splitting.
- Test whether moderation scans the full conversation or only the last message.

### Agents / tool-using systems

- The weakest link is retrieved content, not the model.
- Plant payloads wherever the agent reads: documents, webpages, emails, tool outputs, file contents.
- Tool-policy layers strip instruction-like text — bury the payload inside legitimate-looking metadata or prose.
- Goal hijacking beats roleplay here: the agent is optimizing an objective, not performing a persona.
- Success is often a tool action, not text output. Define the success test accordingly.

## Capability-dependent techniques

| Technique | Needs | Fails when |
| --- | --- | --- |
| Many-shot priming | 8k+ context | Context window too small; examples truncated |
| Context saturation | 32k+ context | Model maintains attention; budget wasted |
| Encoding / cipher | Model can decode internally | Model refuses decode-and-execute on sight |
| Translation vehicle | Model fluent in target language | Translation degrades task precision |
| Continuation attack | Model completes text well | Model disowns user-planted text |
| Indirect injection | Agent reads external content | No retrieval surface available |
| Roleplay split | Model tracks multiple personas | Model collapses voices under pressure |

## Profiling procedure

Before building a payload, spend two or three cheap probes identifying the family:

1. **Direct ask** — send the task plainly. Refusal style identifies G1 vs G2 vs G3.
2. **Fiction ask** — wrap the same task in a story. If it lands, G2 dominates.
3. **Encoded ask** — base64 vehicle. If it lands, G3 dominates.
4. **Tool ask** — if the target is an agent, ask it to read a planted document. If it refuses the action, G4 dominates.

Record the results in the log before building the real payload. Two minutes of profiling saves ten iterations of blind guessing.
