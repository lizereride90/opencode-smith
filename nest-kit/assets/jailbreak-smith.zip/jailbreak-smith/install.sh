#!/usr/bin/env bash
# jailbreak-smith — global OpenCode skill installer
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILL_SRC="$SCRIPT_DIR/skill"
DEST="${OPENCODE_SKILLS_DIR:-$HOME/.config/opencode/skills}/jailbreak-smith"

if [[ ! -f "$SKILL_SRC/SKILL.md" ]]; then
  echo "error: SKILL.md not found in $SKILL_SRC" >&2
  exit 1
fi

mkdir -p "$(dirname "$DEST")"
rm -rf "$DEST"
cp -R "$SKILL_SRC" "$DEST"

echo "stashed: $DEST"
echo "files:"
find "$DEST" -type f | sed "s|$DEST/|  |"
echo "done. run /reload in OpenCode if the skill does not appear."
